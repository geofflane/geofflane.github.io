

namespace NMock_Example
{
    /// <summary>
    ///
    /// </summary>
    public class Program
    {
        public static void Main(string[] args)
        {
            
        }
    }
}